finder
======

Simple file finder.

Install
-------

This app is not ready for production, however you can do following step to get it running:

1. Make sure you have [bower](http://bower.io), then clone this repo

	```
	git clone https://github.com/drafterbit/finder.git
	```

3. Go to cloned directory
	```
	cd finder
	```

3. Install dependencies
	
	```
	bower install
	```

2. Go to demo directory
	```
	cd demo
	```
	
4. Run php server (currently only php available)
	```
	php -S localhost:8000
	```

5. visit `localhost:8000` on your browser


Learn
-----
Documentation is on progress.

License
-------
MIT License
